package oldstuff;

public class Parameters extends TypeValueSet {

	public void addInt(int value) {
		super.addInt(value);
	}


	public void addFloat(float value) {
		super.addFloat(value);
	}
	
}
