package oldstuff;

public class Results extends TypeValueSet{

	int serial;
}
