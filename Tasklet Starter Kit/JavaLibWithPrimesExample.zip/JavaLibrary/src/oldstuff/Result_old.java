package oldstuff;

import enums.DataType;

public class Result_old extends TypeValueElement {

	public Result_old(DataType type, Object value) {
		super(type, value);
	}
	
	
	

}
