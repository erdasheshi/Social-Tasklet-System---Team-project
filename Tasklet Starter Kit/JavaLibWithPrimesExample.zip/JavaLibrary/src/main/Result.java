package main;
import enums.DataType;


public class Result extends Element {

	public Result(DataType type, Object value) {
		super(type, value);
	}

}
