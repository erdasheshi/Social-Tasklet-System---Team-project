package main;
import enums.QocCategory;

public class QoC {

	QocCategory category;
	ParameterList parameters;
	
	public QoC(QocCategory category, ParameterList parameters){
		this.category = category;
		this.parameters = parameters;
	}
	

}
