package main;

public enum Speed {

	MEDIUM,
	FAST,
	FASTEST
	
}
