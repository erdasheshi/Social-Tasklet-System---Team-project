package main;
import enums.DataType;


public class Parameter extends Element{

	public Parameter(DataType type, Object value) {
		super(type, value);
	}

}
