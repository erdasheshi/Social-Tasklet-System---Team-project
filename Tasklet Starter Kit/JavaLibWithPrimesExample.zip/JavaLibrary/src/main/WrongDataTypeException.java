package main;

public class WrongDataTypeException extends Exception {

}
