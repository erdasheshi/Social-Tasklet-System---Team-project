package enums;

public enum QocCategory {

	LOCAL,
	REMOTE,
	SPEED,
	RELIABLE,
	PROXY,
	REDUNDANCY,
	REPLICATION,
	MIGRATION
}
