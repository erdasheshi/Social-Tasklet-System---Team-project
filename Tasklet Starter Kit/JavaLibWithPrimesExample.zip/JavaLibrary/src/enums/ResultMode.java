package enums;

public enum ResultMode {

	INSTANT,
	ALL,
	EVERYTHING

	
}
