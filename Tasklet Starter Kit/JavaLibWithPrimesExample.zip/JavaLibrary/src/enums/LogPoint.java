package enums;

public enum LogPoint {
	SYSTEM_START,
	TASKLET_START,
	RESULT_IN
}
